Backend implementation for Thara.
