# Thara Platform

Thara is a Saudi cultural platform that reimagines heritage as a living, adaptive experience.
From one shared cultural ground, different users experience heritage in different ways.

## Repository Structure

- `/backend` – FastAPI backend
- `/frontend` – Frontend application
- `/ai` – AI prompts and enhancement logic
